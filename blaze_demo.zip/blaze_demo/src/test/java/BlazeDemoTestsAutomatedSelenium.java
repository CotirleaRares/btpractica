import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class BlazeDemoTestsAutomatedSelenium {

    WebDriver driver;
    @BeforeClass
    public void setUp() throws Exception {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ext_rares.cotirlea\\Downloads\\chromedriver-win64 1\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");
        System.out.println("1.open chrome demoblaze");
    }


    @Test
    public void contact() {
        WebElement contact = driver.findElement(By.xpath("//li[2]/a"));
        Highlighter.highlightElement(driver, contact);
       // Actions action= new Actions(driver);
        //action.moveToElement(callcenter).perform();
        contact.click();
        System.out.println("2.look up contact info");
        WaitSleep.plswait(2500);
    }
    @Test
    public void item() {
        WebElement bigx = driver.findElement(By.xpath("//span"));
        Highlighter.highlightElement(driver, bigx);
        bigx.click();
        WaitSleep.plswait(2500);
        WebElement product = driver.findElement(By.xpath("(//body)/div[@id='contcont']/div[1]/div[2]/div[1]/div[1]"));
        Highlighter.highlightElement(driver,product);
        product.click();
        WaitSleep.plswait(2500);
        //WebElement add = driver.findElement(By.xpath("/html[1]/body[1]/div[5]/div[1]/div[2]/div[2]/div[1]/a[1]"));
        //WebElement add = driver.findElement(By.xpath("//a[normalize-space()='Add to cart'"));
        //WebElement add= driver.findElement(By.xpath("//a[contains(text(),'Add to cart'"));
        //driver.get("https://www.demoblaze.com/prod.html?idp_=1");
        //WebElement add = driver.findElement(By.name("Add to cart"));     btn btn-success btn-lg
        //WebElement add = driver.findElement(By.className("col-sm-12"));
       // WebElement add = driver.findElement(By.cssSelector("//div[@class='product-content']/div[@class='col-md-7']/div[@class='col-sm-12']/a[@class='btn']/text()"));
        By addbtn=By.xpath("//a[normalize-space()='Add to cart']");
        WebElement add = driver.findElement(addbtn);
        Highlighter.highlightElement(driver, add);
        add.click();
        System.out.println("3.close x and open product card page");
        WaitSleep.plswait(3000);
        driver.switchTo().alert().accept();
    }
    @Test
    public void wentercart() {
        WebElement cart = driver.findElement(By.xpath("//a[@id='cartur']"));
        Highlighter.highlightElement(driver,cart);
        cart.click();
        WaitSleep.plswait(3000);
        WebElement order = driver.findElement(By.xpath("//button[normalize-space()='Place Order']"));
        Highlighter.highlightElement(driver,order);
        order.click();
        WaitSleep.plswait(3000);
        System.out.println("4.open cart and place order");
    }
    @Test
    public void xplaceorder() {
        WebElement name = driver.findElement(By.xpath("//input[@id='name']"));
        WebElement country = driver.findElement(By.xpath("//input[@id='country']"));
        WebElement city = driver.findElement(By.xpath("//input[@id='city']"));
        WebElement card = driver.findElement(By.xpath("//input[@id='card']"));
        WebElement month = driver.findElement(By.xpath("//input[@id='month']"));
        WebElement year = driver.findElement(By.xpath("//input[@id='year']"));
        WebElement buy = driver.findElement(By.xpath("//button[normalize-space()='Purchase']"));
        Highlighter.highlightElement(driver,name);
        name.sendKeys("John White");
        Highlighter.highlightElement(driver,country);
        country.sendKeys("Romania");
        Highlighter.highlightElement(driver,city);
        city.sendKeys("New York");
        Highlighter.highlightElement(driver,card);
        card.sendKeys("4970 6785 1246 7784");
        Highlighter.highlightElement(driver,month);
        month.sendKeys("april");
        Highlighter.highlightElement(driver,year);
        year.sendKeys("2026");
        Highlighter.highlightElement(driver,buy);
        buy.click();
        WaitSleep.plswait(5500);
        WebElement kk = driver.findElement(By.xpath("//button[normalize-space()='OK']"));
        Highlighter.highlightElement(driver,kk);
        kk.click();
        WaitSleep.plswait(1500);
    }
    @Test
    public void zzbagged() {

        WebElement home = driver.findElement(By.tagName("a"));
        Highlighter.highlightElement(driver, home);
        home.click();
        System.out.println("n-1.go back home");
        WaitSleep.plswait(2000);
    }


    @AfterClass
    public void tearDown() throws Exception {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        driver.quit();
        System.out.println("n.Close Chrome");
    }

}
