import java.io.*;
import java.util.Scanner;


public class WaitSleep {
public static void plswait(int num) {
    try {
        //int num;
        //Scanner s = new Scanner(System.in);
        //num = s.nextInt();
        Thread.sleep(num);
    } catch (InterruptedException e) {
        System.out.println("forced interrupt");
    }
}


}
